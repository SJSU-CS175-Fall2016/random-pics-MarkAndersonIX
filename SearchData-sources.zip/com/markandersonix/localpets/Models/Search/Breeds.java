
package com.markandersonix.localpets.Models.Search;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class Breeds implements Serializable
{

    private Breed breed;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 9038031747005093067L;

    /**
     * 
     * @return
     *     The breed
     */
    public Breed getBreed() {
        return breed;
    }

    /**
     * 
     * @param breed
     *     The breed
     */
    public void setBreed(Breed breed) {
        this.breed = breed;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(breed).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Breeds) == false) {
            return false;
        }
        Breeds rhs = ((Breeds) other);
        return new EqualsBuilder().append(breed, rhs.breed).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
